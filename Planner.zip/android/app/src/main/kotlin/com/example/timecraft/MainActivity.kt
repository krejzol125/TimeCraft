package com.example.timecraft

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
